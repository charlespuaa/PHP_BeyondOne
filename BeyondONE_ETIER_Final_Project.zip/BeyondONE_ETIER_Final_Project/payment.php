<?php
session_start();
// PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/PHPMailer/Exception.php';
require __DIR__ . '/PHPMailer/PHPMailer.php';
require __DIR__ . '/PHPMailer/SMTP.php';

// header and database connection 
include 'header.php';
include 'db.php'; 

// redirect to signin.php if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$cart_items = []; 
$total_price = 0;

$shipping_address = '';
$phone_number = '';
$email_address_for_invoice = '';
$payment_method = '';

// "Buy Now" checkout or regular cart checkout
if (isset($_SESSION['buy_now_item']) && !empty($_SESSION['buy_now_item'])) {
    // "Buy Now" transaction
    $buy_now_item = $_SESSION['buy_now_item'];
    $cart_items[] = $buy_now_item; // add the item to list
    $total_price = $buy_now_item['price'] * $buy_now_item['quantity'];
} else {
    // regular cart checkout
    // fetch cart items for the current user to display in the order summary
    $sql = "SELECT c.id as cart_item_id, p.id as product_id, p.name, p.price, p.image, p.hover_image, c.quantity, c.size
            FROM cart c
            JOIN products p ON c.product_id = p.id
            WHERE c.user_id = ? ORDER BY c.added_at DESC";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("Payment Page: Prepare failed: (" . $conn->errno . ") " . $conn->error);
        $general_error_message = "Database error: Could not prepare cart query.";
    } else {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $cart_items[] = $row;
            $total_price += $row['price'] * $row['quantity'];
        }
        $stmt->close();
    }
}

if (empty($cart_items) && empty($general_error_message)) {
    header('Location: cart.php?empty_checkout=true');
    exit();
}

//error messages for specific fields
$general_error_message = '';
$shipping_address_error = '';
$phone_number_error = '';
$email_error = '';
$payment_method_error = '';


// form processing
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'process_payment') {
    // Get form data
    $shipping_address = htmlspecialchars(trim($_POST['shipping_address'] ?? ''));
    $phone_number = htmlspecialchars(trim($_POST['phone_number'] ?? ''));
    $email_address_for_invoice = htmlspecialchars(trim($_POST['email'] ?? ''));
    $payment_method = htmlspecialchars(trim($_POST['payment_method'] ?? '')); // Ensure this is initialized from POST data

    // flag track overall validation status
    $is_valid = true;

    // shipping add validate
    if (empty($shipping_address)) {
        $shipping_address_error = 'Shipping address is required. ';
        $is_valid = false;
    }

    // phone regex ph
    $cleaned_phone_number = preg_replace('/[^0-9+]/', '', $phone_number); 
    $ph_phone_regex = '/^(09|\+639)\d{9}$/'; //  for 09xxxxxxxxx or +639xxxxxxxxx

    if (empty($phone_number)) {
        $phone_number_error = 'Phone number is required. ';
        $is_valid = false;
    } elseif (!preg_match($ph_phone_regex, $cleaned_phone_number)) {
        $phone_number_error = 'Invalid Philippine phone number format. Use 09xxxxxxxxx or +639xxxxxxxxx. ';
        $is_valid = false;
    }

    // validate Email
    if (empty($email_address_for_invoice)) {
        $email_error = 'Email address is required. 📧';
        $is_valid = false;
    } elseif (!filter_var($email_address_for_invoice, FILTER_VALIDATE_EMAIL)) {
        $email_error = 'Invalid email address format. ';
        $is_valid = false;
    }

    // validate Payment Method
    if (empty($payment_method)) {
        $payment_method_error = 'Please select a payment method. ';
        $is_valid = false;
    }

    if ($is_valid) {
        // invoice email 
        $customer_name_stmt = $conn->prepare("SELECT first_name, last_name FROM users WHERE id = ?");
        $customer_name = 'Customer'; 
        if ($customer_name_stmt) {
            $customer_name_stmt->bind_param("i", $user_id);
            $customer_name_stmt->execute();
            $customer_name_result = $customer_name_stmt->get_result();
            if ($customer_name_row = $customer_name_result->fetch_assoc()) {
                $customer_name = htmlspecialchars($customer_name_row['first_name'] . ' ' . $customer_name_row['last_name']);
            }
            $customer_name_stmt->close();
        }

        $order_items_html = '';
        foreach ($cart_items as $item) {
            $order_items_html .= '
            <tr>
                <td style="padding: 10px; border-bottom: 1px solid #eeeeee;">' . htmlspecialchars($item['name']) . '</td>
                <td style="padding: 10px; border-bottom: 1px solid #eeeeee; text-align: center;">' . htmlspecialchars($item['size']) . '</td>
                <td style="padding: 10px; border-bottom: 1px solid #eeeeee; text-align: center;">' . $item['quantity'] . '</td>
                <td style="padding: 10px; border-bottom: 1px solid #eeeeee; text-align: right;">₱' . number_format($item['price'], 2) . '</td>
                <td style="padding: 10px; border-bottom: 1px solid #eeeeee; text-align: right;">₱' . number_format($item['price'] * $item['quantity'], 2) . '</td>
            </tr>';
        }

        // email body
        $subject = "Etier Clothing - Your Order #" . uniqid() . " is Confirmed!"; // Add a simple unique ID for tracking
        $email_body = '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="color-scheme" content="light dark">
            <meta name="supported-color-schemes" content="light dark">
            <title>Order Confirmation - Etier Clothing</title>
            <style>
                /* General Styles (Light Mode Defaults) */
                body {
                    font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;
                    margin: 0;
                    padding: 0;
                    background-color: #f8f8f8; /* Light background */
                    color: #333; /* Dark text */
                    -webkit-text-size-adjust: 100%;
                    -ms-text-size-adjust: 100%;
                }
                .email-container {
                    max-width: 600px;
                    margin: 20px auto;
                    background-color: #ffffff; /* White container */
                    border-radius: 8px;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
                    overflow: hidden;
                    border: 1px solid #e0e0e0;
                }
                .header {
                    background-color: #E6BD37; /* Gold/Yellow from your CSS */
                    padding: 30px 20px;
                    text-align: center;
                    color: #ffffff;
                }
                .header h1 {
                    margin: 0;
                    font-size: 28px;
                    font-weight: 600;
                    letter-spacing: 1px;
                }
                .content {
                    padding: 25px 30px;
                    line-height: 1.6;
                    font-size: 15px;
                }
                .content p {
                    margin-bottom: 15px;
                }
                .content .highlight {
                    color: #E6BD37;
                    font-weight: bold;
                }
                .order-details-table {
                    width: 100%;
                    border-collapse: collapse;
                    margin: 25px 0;
                    font-size: 14px;
                    background-color: #fdfdfd; /* Light table background */
                    border: 1px solid #eeeeee;
                }
                .order-details-table th, .order-details-table td {
                    padding: 12px 15px;
                    text-align: left;
                    border-bottom: 1px solid #eeeeee;
                }
                .order-details-table th {
                    background-color: #f2f2f2; /* Light table header background */
                    color: #555;
                    font-weight: 600;
                    text-transform: uppercase;
                }
                .order-details-table tr:last-child td {
                    border-bottom: none;
                }
                .total-section {
                    text-align: right;
                    font-size: 16px;
                    font-weight: bold;
                    padding: 15px 0;
                    border-top: 2px solid #E6BD37;
                    margin-top: 20px;
                }
                .footer {
                    background-color: #333333; /* Dark footer */
                    color: #bbbbbb; /* Light text on dark footer */
                    text-align: center;
                    padding: 20px 0;
                    font-size: 12px;
                }
                .footer a {
                    color: #E6BD37;
                    text-decoration: none;
                }
                .button {
                    display: inline-block;
                    background-color: #000000; /* Black button */
                    color: #ffffff; /* White text on black button */
                    padding: 12px 25px;
                    text-decoration: none;
                    border-radius: 5px;
                    font-weight: bold;
                    margin-top: 20px;
                    transition: background-color 0.3s ease;
                }
                .button:hover {
                    background-color: #E6BD37; /* Gold/Yellow on hover */
                }

                /* Dark Mode Styles */
                @media (prefers-color-scheme: dark) {
                    body {
                        background-color: #1a1a1a !important; /* Darker background */
                        color: #e0e0e0 !important; /* Lighter text */
                    }
                    .email-container {
                        background-color: #2a2a2a !important; /* Darker container */
                        border: 1px solid #3a3a3a !important;
                    }
                    .content, .content p {
                        color: #e0e0e0 !important; /* Ensure content text is light */
                    }
                    .header {
                        background-color: #c9a12c !important; /* Slightly adjusted gold for dark mode */
                        color: #ffffff !important;
                    }
                    .order-details-table {
                        background-color: #3a3a3a !important; /* Darker table background */
                        border: 1px solid #4a4a4a !important;
                    }
                    .order-details-table th {
                        background-color: #4a4a4a !important; /* Darker table header background */
                        color: #ffffff !important;
                    }
                    .order-details-table td {
                         border-bottom: 1px solid #4a4a4a !important;
                         color: #e0e0e0 !important; /* Ensure table cell text is light */
                    }
                    .total-section {
                        border-top: 2px solid #c9a12c !important; /* Adjusted gold for dark mode */
                    }
                    .highlight {
                        color: #E6BD37 !important; /* Keep highlight color consistent */
                    }
                    .footer {
                        background-color: #1a1a1a !important; /* Darker footer */
                        color: #aaaaaa !important; /* Slightly lighter text on dark footer */
                    }
                    .footer a {
                        color: #E6BD37 !important; /* Keep link color consistent */
                    }
                    .button {
                        background-color: #555555 !important; /* Darker button for dark mode */
                        color: #ffffff !important;
                    }
                    .button:hover {
                        background-color: #c9a12c !important; /* Adjusted gold on hover for dark mode */
                    }
                }
            </style>
        </head>
        <body>
            <div class="email-container">
                <div class="header">
                    <h1>ETIER CLOTHING</h1>
                    <p style="margin-top: 10px; font-size: 16px; color: #ffffff;">Order Confirmation</p>
                </div>
                <div class="content">
                    <p style="color: #333;">Dear <strong style="color: #E6BD37;">' . $customer_name . '</strong>,</p>
                    <p style="color: #333;">Thank you for your recent purchase from ETIER Clothing! Your order has been successfully placed and is being processed.</p>
                    <p style="color: #333;">Below is a summary of your order:</p>

                    <table class="order-details-table" style="width: 100%; border-collapse: collapse; margin: 25px 0; font-size: 14px; background-color: #fdfdfd; border: 1px solid #eeeeee;">
                        <thead>
                            <tr>
                                <th style="padding: 12px 15px; text-align: left; background-color: #f2f2f2; color: #555; font-weight: 600; text-transform: uppercase; border-bottom: 1px solid #eeeeee;">Item</th>
                                <th style="padding: 12px 15px; text-align: center; background-color: #f2f2f2; color: #555; font-weight: 600; text-transform: uppercase; border-bottom: 1px solid #eeeeee;">Size</th>
                                <th style="padding: 12px 15px; text-align: center; background-color: #f2f2f2; color: #555; font-weight: 600; text-transform: uppercase; border-bottom: 1px solid #eeeeee;">Qty</th>
                                <th style="padding: 12px 15px; text-align: right; background-color: #f2f2f2; color: #555; font-weight: 600; text-transform: uppercase; border-bottom: 1px solid #eeeeee;">Price</th>
                                <th style="padding: 12px 15px; text-align: right; background-color: #f2f2f2; color: #555; font-weight: 600; text-transform: uppercase; border-bottom: 1px solid #eeeeee;">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            ' . $order_items_html . '
                        </tbody>
                    </table>

                    <div class="total-section" style="text-align: right; font-size: 16px; font-weight: bold; padding: 15px 0; border-top: 2px solid #E6BD37; margin-top: 20px;">
                        Order Total: <span style="color: #E6BD37;">₱' . number_format($total_price, 2) . '</span>
                    </div>

                    <p style="color: #333;"><strong>Shipping Details:</strong><br>
                    Address: ' . htmlspecialchars($shipping_address) . '<br>
                    Phone: ' . htmlspecialchars($phone_number) . '<br>
                    Payment Method: ' . htmlspecialchars($payment_method) . '</p>

                    <p style="color: #333;">You will receive another email with tracking information once your order has shipped.</p>

                

                    <p style="color: #333;">If you have any questions, please don\'t hesitate to contact our customer support team.</p>
                    <p style="color: #333;">Thank you for choosing ETIER!</p>
                    <p style="color: #333;">Warm regards,<br>
                    The Etier Clothing Team</p>
                </div>
                <div class="footer" style="background-color: #333333; color: #bbbbbb; text-align: center; padding: 20px 0; font-size: 12px;">
                    &copy; ' . date("Y") . ' ETIER Clothing. All rights reserved.<br>
                    <a href="https://www.facebook.com/charlesspuaa/" style="color: #E6BD37; text-decoration: none;">ETIER.com</a> | <a href="YOUR_CONTACT_LINK" style="color: #E6BD37; text-decoration: none;">Contact Us</a><br>
                    <span style="font-size: 10px; color: #888888;">This email is for educational purposes only and is a final project requirement.</span>
                </div>
            </div>
        </body>
        </html>';

        // PHPMailer setup
        $mail = new PHPMailer(true); // Passing `true` enables exceptions

        try {
            //server settings
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com'; // or your SMTP host
            $mail->SMTPAuth   = true;
            $mail->Username   = 'iacedos11@gmail.com'; // Your Gmail address (or sending email)
            $mail->Password   = 'jmtipygfrkhamygu'; // Your Gmail App Password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Use ENCRYPTION_SMTPS for port 465
            $mail->Port       = 587; // 465 for SMTPS, 587 for STARTTLS

            //recipients
            $mail->setFrom('iacedos11@gmail.com', 'ETIER Clothing'); // Sender email and name
            $mail->addAddress($email_address_for_invoice, $customer_name); // Recipient's email and name

            // content
            $mail->isHTML(true); 
            $mail->Subject = $subject;
            $mail->Body     = $email_body;
            $mail->AltBody = strip_tags(str_replace('<br>', "\n", $email_body)); // Plain text version of the email body

            $mail->send();
            // sent email
        } catch (Exception $e) {
            error_log("Failed to send order confirmation email to " . $email_address_for_invoice . " for user " . $user_id . ". Mailer Error: {$mail->ErrorInfo} Exception: {$e->getMessage()}");
            //  general error message visible to the user
            $general_error_message = "Your order was placed, but we had trouble sending the confirmation email. Please check your spam folder or contact support if you don't receive it. Mailer Error: {$mail->ErrorInfo}";
        }

        // clear cart items or buy_now_item after "successful" order placement 
        if (isset($_SESSION['buy_now_item'])) {
            unset($_SESSION['buy_now_item']);
        } else {
            $clear_cart_stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
            if ($clear_cart_stmt === false) {
                error_log("Payment Page: Clear cart prepare failed: (" . $conn->errno . ") " . $conn->error);
            } else {
                $clear_cart_stmt->bind_param("i", $user_id);
                $clear_cart_stmt->execute();
                $clear_cart_stmt->close();
            }
        }

        // Redirect to order_placed.php
        if (!headers_sent()) {
            header('Location: order_placed.php');
            exit();
        } else {
            echo '<script>window.location.href = "order_placed.php";</script>';
            exit();
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout | Etier</title>
    <style>
        body {
            font-family: 'Proxima Nova', sans-serif;
            background-color: #ffffffff;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .page-content {
            flex: 1;
            padding-top: 130px;
            padding-bottom: 90px;
        }
        .checkout-container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            position: relative; 
        }
        .checkout-header {
            width: 100%;
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 10px;
            text-align: center;
            color: #333;
        }
        .order-summary-section, .payment-details-section {
            flex: 1;
            min-width: 300px;
        }
        .section-title {
            font-size: 22px;
            font-weight: bold;
            margin-bottom: 20px;
            color: #E6BD37;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
        }
        .order-item {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px dashed #eee;
        }
        .order-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        .order-item-image {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        .order-item-info {
            flex-grow: 1;
        }
        .order-item-name {
            font-weight: bold;
            font-size: 16px;
        }
        .order-item-details {
            font-size: 13px;
            color: #666;
        }
        .order-total-summary {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 2px solid #E6BD37;
            font-size: 20px;
            font-weight: bold;
            text-align: right;
        }
        .form-group {
            margin-bottom: 20px;
            position: relative; 
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }
        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="tel"],
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            box-sizing: border-box;
            transition: border-color 0.3s ease; 
        }
        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }
        
        .form-group.error input,
        .form-group.error textarea,
        .form-group.error select {
            border-color: #dc3545; 
        }
        .input-error-message {
            color: #dc3545;
            font-size: 0.85em;
            margin-top: 5px;
            display: block; 
            font-weight: normal;
        }

        .payment-options {
            margin-top: 20px;
            margin-bottom: 30px;
        }
        .payment-option {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        .payment-option input[type="radio"] {
            margin-right: 10px;
        }
        .place-order-btn {
            background: black;
            color: white;
            border: none;
            padding: 15px 30px;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: 100%;
            font-size: 18px;
        }
        .place-order-btn:hover {
            background-color: #E6BD37;
        }
        .general-error-message { 
            color: #dc3545;
            text-align: center;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .email-invoice-note {
            font-size: 0.9em;
            color: #888;
            margin-top: 5px;
            display: block;
            font-weight: normal;
        }

       
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            background: none;
            border: none;
            color: #333; 
            font-size: 16px;
            font-weight: bold; 
            cursor: pointer;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 5px;
            padding: 5px 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        .back-button:hover {
            background-color: #E6BD37;
            color: #fff; 
        }
        .back-button svg {
            width: 18px;
            height: 18px;
            fill: currentColor; 
        }


        @media (max-width: 768px) {
            .page-content {
                padding-top: 100px;
            }
            .checkout-container {
                flex-direction: column;
                padding: 20px; 
                margin: 0 15px;
            }
            .order-summary-section, .payment-details-section {
                min-width: unset;
                width: 100%;
            }
            .section-title {
                text-align: center;
            }
            .back-button {
                top: 15px;
                left: 15px;
                font-size: 14px;
                padding: 3px 8px;
            }
            .back-button svg {
                width: 16px;
                height: 16px;
            }
        }
    </style>
</head>
<body>
    <div class="page-content">
        <div class="checkout-container">
            <!-- Back Button -->
            <a href="cart.php" class="back-button">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/></svg>
                Back to Cart
            </a>

            <h1 class="checkout-header">Checkout</h1>

            <?php
            // Display general error message if set
            if (!empty($general_error_message)) {
                echo '<p class="general-error-message">' . htmlspecialchars($general_error_message) . '</p>';
            }
            ?>

            <div class="order-summary-section">
                <h2 class="section-title">Order Summary</h2>
                <?php if (empty($cart_items)): ?>
                    <p class="empty-cart-message" style="text-align: left; font-size: 1em; color: #555;">No items to display for checkout.</p>
                <?php else: ?>
                    <?php foreach ($cart_items as $item): ?>
                        <div class="order-item">
                            <img src="../assets/<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>" class="order-item-image">
                            <div class="order-item-info">
                                <div class="order-item-name"><?= htmlspecialchars($item['name']) ?></div>
                                <div class="order-item-details">
                                    Quantity: <?= $item['quantity'] ?> | Size: <?= htmlspecialchars($item['size']) ?> | ₱<?= number_format($item['price'], 2) ?> each
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <div class="order-total-summary">
                        Total: ₱<?= number_format($total_price, 2) ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="payment-details-section">
                <h2 class="section-title">Shipping & Payment</h2>
                <form action="payment.php" method="POST">
                    <input type="hidden" name="action" value="process_payment">

                    <div class="form-group <?= !empty($shipping_address_error) ? 'error' : '' ?>">
                        <label for="shipping_address">Shipping Address:</label>
                        <textarea id="shipping_address" name="shipping_address" rows="3" required placeholder="Enter your full shipping address"><?= htmlspecialchars($shipping_address) ?></textarea>
                        <?php if (!empty($shipping_address_error)): ?>
                            <span class="input-error-message"><?= $shipping_address_error ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group <?= !empty($phone_number_error) ? 'error' : '' ?>">
                        <label for="phone_number">Phone Number:</label>
                        <input type="tel" id="phone_number" name="phone_number" value="<?= htmlspecialchars($phone_number) ?>" required placeholder="+639xxxxxxxxx or 09xxxxxxxxx">
                        <?php if (!empty($phone_number_error)): ?>
                            <span class="input-error-message"><?= $phone_number_error ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group <?= !empty($email_error) ? 'error' : '' ?>">
                        <label for="email">Email Address:</label>
                        <input type="email" id="email" name="email" value="<?= htmlspecialchars($email_address_for_invoice) ?>" required placeholder="your.email@example.com">
                        <small class="email-invoice-note">Your invoice and order updates will be sent to this email address.</small>
                        <?php if (!empty($email_error)): ?>
                            <span class="input-error-message"><?= $email_error ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group <?= !empty($payment_method_error) ? 'error' : '' ?>">
                        <label for="payment_method_select">Payment Method:</label>
                        <select id="payment_method_select" name="payment_method" required>
                            <option value="">Select a method</option>
                            <option value="Credit Card" <?= ($payment_method === 'Credit Card' ? 'selected' : '') ?>>Credit Card</option>
                            <option value="GCash" <?= ($payment_method === 'GCash' ? 'selected' : '') ?>>GCash</option>
                            <option value="Bank Transfer" <?= ($payment_method === 'Bank Transfer' ? 'selected' : '') ?>>Bank Transfer</option>
                            <option value="Cash on Delivery" <?= ($payment_method === 'Cash on Delivery' ? 'selected' : '') ?>>Cash on Delivery (COD)</option>
                        </select>
                        <?php if (!empty($payment_method_error)): ?>
                            <span class="input-error-message"><?= $payment_method_error ?></span>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="place-order-btn">Place Order</button>
                </form>
            </div>
        </div>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>
