<?php
include 'header.php'; 

$first_name = $_POST['first_name'] ?? '';
$middle_name = $_POST['middle_name'] ?? '';
$last_name = $_POST['last_name'] ?? '';
$birthday = $_POST['birthday'] ?? '';
$email = $_POST['email'] ?? '';
$contact_number = $_POST['contact_number'] ?? '';

$street_name = $_POST['street_name'] ?? '';
$house_number = $_POST['house_number'] ?? '';
$building = $_POST['building'] ?? '';
$postal_code = $_POST['postal_code'] ?? '';
$barangay = $_POST['barangay'] ?? '';
$province = $_POST['province'] ?? '';
$city = $_POST['city'] ?? '';
$region = $_POST['region'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registration - Address</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            overflow-x: hidden; 
        }

        body {
            font-family: Arial, sans-serif;
            color: #000;
            background: #fff;
            display: flex; 
            flex-direction: column; 
            padding-top: 115px; 
            box-sizing: border-box; 
        }

       
        .main-content-wrapper {
            flex: 1; 
            padding: 20px; 
            padding-bottom: 50px; 
            box-sizing: border-box;
            width: 100%; 
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2rem;
        }

        fieldset {
            border: 2px solid #E6BD37;
            border-radius: 10px;
            padding: 20px;
            background: #fff;
            width: 90%; 
            max-width: 500px; 
            margin: auto; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transition: transform 0.2s, box-shadow 0.2s;
            box-sizing: border-box; 
        }
        fieldset:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 18px rgba(0,0,0,0.15);
        }

        legend {
            font-weight: bold;
            color: #E6BD37;
            font-size: 1.2rem; 
        }

        label {
            display: block;
            margin-top: 15px;
            font-size: 1rem; 
        }

        input[type="text"] {
            width: 100%;
            padding: 10px; 
            margin-top: 6px; 
            font-size: 1rem;
            border: 1px solid #ccc;
            border-radius: 5px;
            background: #F9F9F9;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background: #E6BD37;
            color: #fff;
            font-weight: bold;
            margin-top: 20px;
            padding: 14px; 
            font-size: 1.1rem; 
            width: 100%;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s, color 0.3s, border 0.3s;
        }
        input[type="submit"]:hover {
            background: #fff;
            color: #E6BD37;
            border: 2px solid #E6BD37;
        }

        /* Responsiveness */
        @media (max-width: 768px) {
            body {
                padding-top: 130px; 
            }
            .main-content-wrapper {
                padding: 15px; 
                padding-bottom: 40px;
            }
            h1 {
                font-size: 1.7rem;
            }
            fieldset {
                padding: 16px;
            }
            input[type="submit"] {
                font-size: 1rem;
                padding: 10px;
            }
            label {
                font-size: 0.95rem;
            }
        }

        @media (max-width: 480px) {
            body {
                padding-top: 100px; 
            }
            .main-content-wrapper {
                padding: 10px; 
                padding-bottom: 30px; 
            }
            h1 {
                font-size: 1.5rem;
            }
            fieldset {
                padding: 14px;
            }
            input[type="text"] {
                padding: 8px;
                font-size: 0.95rem;
            }
            input[type="submit"] {
                font-size: 0.95rem;
                padding: 9px;
            }
            label {
                font-size: 0.9rem; /* Slightly smaller for small screens */
            }
        }
    </style>
</head>
<body>

    <div class="main-content-wrapper">
        <h1>Registration</h1>
        <form method="post" action="account_info_reg.php">
            <fieldset>
                <legend>Address Information</legend>

                <label>Street Name</label>
                <input type="text" name="street_name" required value="<?= htmlspecialchars($street_name) ?>">

                <label>House Number</label>
                <input type="text" name="house_number" required value="<?= htmlspecialchars($house_number) ?>">

                <label>Building (Optional)</label>
                <input type="text" name="building" value="<?= htmlspecialchars($building) ?>">

                <label>Postal Code</label>
                <input type="text" name="postal_code" required pattern="[1-9][0-9]{3}" value="<?= htmlspecialchars($postal_code) ?>">

                <label>Barangay</label>
                <input type="text" name="barangay" required value="<?= htmlspecialchars($barangay) ?>">

                <label>Province</label>
                <input type="text" name="province" required value="<?= htmlspecialchars($province) ?>">

                <label>City</label>
                <input type="text" name="city" required value="<?= htmlspecialchars($city) ?>">

                <label>Region</label>
                <input type="text" name="region" required value="<?= htmlspecialchars($region) ?>">

                <input type="hidden" name="first_name" value="<?= htmlspecialchars($first_name) ?>">
                <input type="hidden" name="middle_name" value="<?= htmlspecialchars($middle_name) ?>">
                <input type="hidden" name="last_name" value="<?= htmlspecialchars($last_name) ?>">
                <input type="hidden" name="birthday" value="<?= htmlspecialchars($birthday) ?>">
                <input type="hidden" name="email" value="<?= htmlspecialchars($email) ?>">
                <input type="hidden" name="contact_number" value="<?= htmlspecialchars($contact_number) ?>">

                <input type="submit" value="Next">
            </fieldset>
        </form>
    </div>

<?php include 'footer.php'; ?>
</body>
</html>