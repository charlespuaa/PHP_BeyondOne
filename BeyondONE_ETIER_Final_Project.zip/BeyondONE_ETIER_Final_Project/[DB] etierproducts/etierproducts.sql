-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql210.infinityfree.com
-- Generation Time: Jul 20, 2025 at 01:10 PM
-- Server version: 11.4.7-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_39481257_etierproducts`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `size` varchar(10) NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `product_id`, `quantity`, `size`, `added_at`) VALUES
(5, 22, 1, 1, 'L', '2025-07-19 04:08:05'),
(6, 22, 7, 1, 'S', '2025-07-19 04:13:20');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `category` varchar(50) NOT NULL,
  `size` varchar(30) NOT NULL,
  `has_size` tinyint(1) NOT NULL DEFAULT 0,
  `price` decimal(10,2) UNSIGNED NOT NULL,
  `image` varchar(100) NOT NULL,
  `hover_image` varchar(100) NOT NULL,
  `stock` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `category`, `size`, `has_size`, `price`, `image`, `hover_image`, `stock`) VALUES
(1, 'Malbom Golf Hat', '100% cotton golf cap with adjustable back strap and embroided logo', 'Hats and Caps', 'Small', 1, '2711.03', 'hats_and_caps/MGOLF_cap_front.png', 'hats_and_caps/MGOLF_cap_back.png', 10),
(2, 'Legend Trucker Hat', '53% polyester and 47% cotton cap with adjustable back strap and mesh back panel', 'Hats and Caps', 'Small', 1, '2823.99', 'hats_and_caps/LEGENDS_cap_front.png', 'hats_and_caps/LEGENDS_cap_back.png', 15),
(3, 'Bear Loft Bucket Hat', '100% cotton with canvas fabric and a front embroided graphic logo detail', 'Hats and Caps', 'Small', 1, '3923.22', 'hats_and_caps/BEAR_buckethat_front.png', 'hats_and_caps/BEAR_buckethat_back.png', 3),
(4, 'Heart Patch Baseball Cap', '100% cotton baseball cap with adjustable back strap, front patch detail, and ventilating eyelets', 'Hats and Caps', 'Small', 1, '4461.90', 'hats_and_caps/HEARTS_cap_front.png', 'hats_and_caps/HEARTS_cap_back.png', 13),
(5, 'Market Studio Beanie', '100% acrylic beanie with an embroided logo detail and ribbed knit fabric', 'Hats and Caps', 'Small', 1, '1129.80', 'hats_and_caps/MARKETSTUDIOS_beanie_front.png', 'hats_and_caps/MARKETSTUDIOS_beanie_back.png', 8),
(6, 'Jones Aviator Sunglasses', 'Silver-tone metal frame sunglasses', 'Eyewear', 'One Size', 0, '3321.89', 'eyewear/JONESAVIATOR_front.png', 'eyewear/JONESAVIATOR_side.png', 32),
(7, 'Earl Sunglasses', 'Acetate frame with sof case and cleaning cloth included', 'Eyewear', 'One Size', 0, '4322.98', 'eyewear/EARL_front.png', 'eyewear/EARL_side.png', 4),
(8, 'Oval Sunglasses', 'Acetate frame with sof case and cleaning cloth included', 'Eyewear', 'One Size', 0, '32382.21', 'eyewear/OVAL_front.png', 'eyewear/OVAL_side.png', 9),
(9, 'Pluto Sunglasses', 'Acetate frame with sof case and cleaning cloth included', 'Eyewear', 'One Size', 0, '2202.71', 'eyewear/PLUTO_front.png', 'eyewear/PLUTO_side.png', 19),
(10, 'Tag 3.0 Sunglasses', 'Silver-tone metal frame sunglasses', 'Eyewear', 'One Size', 0, '23311.29', 'eyewear/TAG3_front.png', 'eyewear/TAG3_back.png', 4),
(11, 'Biliwin', 'Laptop Handbag with removable adjustable crossbody strap', 'Hand Bags', 'Large', 0, '3000.00', 'handbags/BILIWIN_front.png', 'handbags/BILIWIN_side.png', 12),
(12, 'Wigoand', 'Messenger bag with non-removable adjustable crossbody strap', 'Hand Bags', 'Medium', 0, '2500.00', 'handbags/WIGOAND_front.png', 'handbags/WIGOAND_side.png', 8),
(13, 'Tardes', 'Backpack with adjustable shoulder strap and two compartments', 'Hand Bags', 'Large', 0, '3400.00', 'handbags/TARDES_front.png', 'handbags/TARDES_back.png', 5),
(14, 'Seawave', 'Cross body bag with non-removable adjustable crossbody strap with one compartment', 'Hand Bags', 'Small', 0, '2400.00', 'handbags/SEAWAVE_front.png', 'handbags/SEAWAVE_side.png', 5),
(15, 'Tonstrina 17', '17 is a classic and impeccable fougere construction and a clear contrast between fresh and aromatic notes', 'Fragrance', '100ml', 0, '3200.20', 'fragrance/TONSTRINA17_front.png', 'fragrance/TONSTRINA17_back.png', 5),
(16, 'Tonstrina 55', '55 is woody parfum de cologne that wants to embody all the strength and elegeance of the person that wears it', 'Fragrance', '100ml', 0, '3200.20', 'fragrance/TONSTRINA55_front.png', 'fragrance/TONSTRINA55_back.png', 5),
(17, 'Tonstrina 376', '367 is a fresh and bitter citrus parfum de cologne that elegantly claims a modern and lively style', 'Fragrance', '100ml', 0, '3200.20', 'fragrance/TONSTRINAA367_front.png', 'fragrance/TONSTRINA367_back.png', 5),
(18, 'Fisherman Sandal', 'Leather upper and manmade sole with adjustabe ankle strap', 'Shoes', '7', 1, '9319.17', 'shoes/fisherman_front.png', 'shoes/fisherman_back.png', 10),
(19, 'Lowell Oxford Shoes', 'Croc embossed leather upper with oil-resistant sole', 'Shoes', '7', 1, '9600.57', 'shoes/oxford_front.png', 'shoes/oxford_back.png', 10),
(20, 'Adrian', 'Leather upper with oil-resistant sole with tassel detail and fringe trim', 'Shoes', '7', 1, '8400.89', 'shoes/adrian_front.png', 'shoes/adrian_back.png', 10),
(21, 'Speedcat OG', 'Suede upper with rubber sole and lace-up front', 'Shoes', '7', 1, '5647.90', 'shoes/puma_front.png', 'shoes/puma_back.png', 10),
(22, 'Coors Beer Cropped Tee', '100% Cotton with a front graphic design', 'Tops', 'XS', 1, '2711.03', 'tops/coors_front.png', 'tops/coors_back.png', 20),
(23, 'Stripe Graphic Tee', '100% Cotton with a front graphic design', 'Tops', 'XS', 1, '2251.03', 'tops/toms_front.png', 'tops/toms_back.png', 60),
(24, 'Wanted Tee', '100% Cotton with a front graphic design', 'Tops', 'XS', 1, '3388.03', 'tops/wanted_front.png', 'tops/wanted_back.png', 5),
(25, 'Underground Polo Shirt', '100% Cotton with a front graphic design', 'Tops', 'XS', 1, '7008.03', 'tops/allsaints_front.png', 'tops/allsaints_back.png', 15),
(26, 'Bait and Tackle Tee', '100% Cotton with a front graphic design', 'Tops', 'XS', 1, '2938.64', 'tops/bat_front.png', 'tops/bat_back.png', 15),
(27, 'Berkley Pant', '100% cotton with adjustable belt and waistband', 'Bottoms', 'XS', 1, '8728.12', 'bottoms/berkley_front.png', 'bottoms/berkley_back.png', 7),
(28, 'Track Pants', '100% nylon with drawstring closure', 'Bottoms', 'XS', 1, '3473.90', 'bottoms/track_front.png', 'bottoms/track_back.png', 20),
(29, 'Monogram Chino Pant', '100% cotton with side seam pockets and back welt pockets', 'Bottoms', 'XS', 1, '6783.22', 'bottoms/chino_front.png', 'bottoms/chino_back.png', 10),
(30, 'Morel Nicola Terry Short', '100% cotton with drawstring closure and elasic waistband', 'Bottoms', 'XS', 1, '5400.22', 'bottoms/terry_front.png', 'bottoms/terry_back.png', 15),
(31, 'Underground Swim Shorts', '100% cotton with side pockets and single rear pocket', 'Bottoms', 'XS', 1, '6571.99', 'bottoms/swim_front.png', 'bottoms/swim_back.png', 15),
(32, 'Polycarbon 37mm Watch', 'Polycarbonate case and strap with brass dial, indexes, and hands', 'Accessories', 'One Size', 0, '11000.20', 'accessories/polycarbonwhite_front.png', 'accessories/polycarbonwhite_back.png', 4),
(33, 'Leather Suffield Belt', '100% cowhide leather with silver-tone buckle closure', 'Accessories', 'One Size', 0, '4555.90', 'accessories/suffiled_front.png', 'accessories/suffiled_back.png', 10),
(34, 'Recycled Cotton Logo Socks', '80% cotton socks', 'Accessories', 'One Size', 0, '3000.90', 'accessories/creamsocks_front.png', 'accessories/sockscream_back.png', 10),
(35, 'Cornet Ring', 'Gold-plated sterling silver', 'Accessories', 'One Size', 0, '5900.20', 'accessories/cornetring_front.png', 'accessories/cornetring_back.png', 3),
(36, 'Hybridge Lite Vest', '100% polyamide with two-way front zipper closure', 'Jackets', 'XS', 1, '29882.90', 'jackets/goose_front.png', 'jackets/goose_back.png', 11),
(37, 'Rhett Jacket', '100% cotton with 4-pcoket styling', 'Jackets', 'XS', 1, '32412.20', 'jackets/rhett_front.png', 'jackets/rhett_back.png', 18),
(38, 'Work Shirt', '100% polyester made from lightweight fleece fabric', 'Jackets', 'XS', 1, '7829.90', 'jackets/pattern_front.png', 'jackets/pattern_back.png', 8),
(39, 'NYC Cafe Racer Jacket', '100% polyester made from heavyweight buttery leather fabric', 'Jackets', 'XS', 1, '45673.90', 'jackets/scholt_front.png', 'jackets/scholt_back.png', 23),
(40, 'Mission Jacket', '100% cotton and 100% recycled polyester', 'Jackets', 'XS', 1, '8536.90', 'jackets/mission_front.png', 'jackets/mission_back.png', 21);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `first_name` varchar(250) NOT NULL,
  `middle_name` varchar(250) DEFAULT NULL,
  `last_name` varchar(250) NOT NULL,
  `birthday` date NOT NULL,
  `street_name` varchar(250) NOT NULL,
  `house_number` varchar(250) NOT NULL,
  `building` varchar(250) DEFAULT NULL,
  `barangay` varchar(250) NOT NULL,
  `city` varchar(250) NOT NULL,
  `region` varchar(250) NOT NULL,
  `province` varchar(250) NOT NULL,
  `postal_code` int(25) NOT NULL,
  `password` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `contact_number` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `middle_name`, `last_name`, `birthday`, `street_name`, `house_number`, `building`, `barangay`, `city`, `region`, `province`, `postal_code`, `password`, `username`, `email`, `contact_number`, `created_at`) VALUES
(22, 'Alexa Joyce', 'Gameng', 'Cueto', '2006-02-03', 'Kisapmata', '231', '', 'Bangkal', 'City of Makati', 'NCR', 'Metro Manila', 1235, '$2y$10$NZu6hpmKJTCunL7IivS8peS7vEbnYUsTHm8J7yoAQX5e./0giUf/6', 'jojo_20', 'alexajoyce130@gmail.com', '09892677891', '2025-07-18 23:54:24'),
(23, 'TEST5', 'Viray', 'Collo', '2005-05-18', 'Sunny Street', '143 Sola', 'Stormy Building', 'Barangay Alexa', 'Choco City', 'NCR', 'Spyro Province', 1111, '$2y$10$lmPNf49vPOdcVFWae7n6ROu1jeAH.vhwwLG7DUcMrN49cn6TqPstC', 'TEST5', 'paulbenedictcollo@gmail.com', '09123456789', '2025-07-19 02:42:10'),
(24, 'Charles Michael', 'Galo', 'Pua', '2005-07-24', '20', '20', '', '97', 'Caloocan', 'NCR', 'Metro Manila', 4100, '$2y$10$cdpUDm6kiW44sOkfmMXOIuYt60TjH5DNG5DVIJt3cPKcFAkCqwXEy', 'charles', 'charlespuasdf@gmail.com', '09766491851', '2025-07-20 15:18:39'),
(25, 'Mandy', 'Fabian', 'Barcelona', '2005-07-11', 'Ilang-Ilang st.', '115', '', '97', 'Caloocan City', 'NCR', 'Metro Manila', 1400, '$2y$10$y/WOM.YmlzSMDZN.7LynsuCkLV7HsPd.qQUcGwU/dzM.3nOH2TvlG', 'Nicole_Mandy', 'nicolebarcelona07@gmail.com', '09544993155', '2025-07-20 15:41:23'),
(26, 'Diego', '', 'Geronimo ', '2003-01-16', 'Socorro maypajo ', '9', '', '26', 'Caloocan City ', 'll', 'Metro manila', 1410, '$2y$10$5Skp0Vk87o1S/ESnRxmf2O6rk3h5vByzq9bS1uVI9vj.Mk/sZT38q', 'R_geronimo', 'geronimornz@gmail.com', '09185160783', '2025-07-20 15:53:37'),
(27, 'Melanie', 'Orpilla', 'Gameng', '2003-03-01', 'Paladian Street', '4938', '', 'Bangkal', 'CITY OF MAKATI', 'NCR', 'METRO MANILA', 1235, '$2y$10$mX.4rwx8EjnTvZN1pNkIIuNf9L8.CXIlpvc5YAm5C5MNLZ4zvGMpu', 'makimaki30', 'melaniegcueto30@gmail.com', '09455574721', '2025-07-20 15:54:46');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`,`product_id`,`size`),
  ADD KEY `fk_product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `fk_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
