<?php
// account_info_req.php - Personal Information Registration Step

// IMPORTANT: Ensure session_start() is called only once at the very beginning of any script that uses sessions.
// If your header.php already calls it, remove it from here.
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Fetch and sanitize POST data for persistence
// Using filter_input for slightly safer input handling
$first_name = trim(filter_input(INPUT_POST, 'first_name', FILTER_SANITIZE_STRING) ?? '');
$middle_name = trim(filter_input(INPUT_POST, 'middle_name', FILTER_SANITIZE_STRING) ?? '');
$last_name = trim(filter_input(INPUT_POST, 'last_name', FILTER_SANITIZE_STRING) ?? '');
$birthday = filter_input(INPUT_POST, 'birthday', FILTER_SANITIZE_STRING) ?? ''; // Date format might be sensitive to sanitization
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL) ?? '';
$contact_number = trim(filter_input(INPUT_POST, 'contact_number', FILTER_SANITIZE_STRING) ?? '');

// It's generally best to include header.php at the very top, before any HTML output,
// especially if header.php defines the <!DOCTYPE html> and <html> tags.
// Moving it here to ensure it's loaded before any HTML is sent.
include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registration - Personal Information</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style>
    /* Sticky Footer CSS - Consistent across pages */
    html, body {
        height: 100%;
        margin: 0;
        padding: 0;
        overflow-x: hidden; /* Prevent horizontal scrolling caused by layout issues */
    }

    body {
        font-family: Arial, sans-serif;
        color: #000;
        background: #fff;
        display: flex; /* Use flexbox for sticky footer */
        flex-direction: column; /* Stack children vertically */
        box-sizing: border-box; /* Include padding in element's total width and height */
        padding-top: 115px; /* Default for larger screens. Adjust if your header is smaller by default. */
    }

    /* Main content wrapper to handle page-wide horizontal padding */
    .main-content-wrapper {
        flex: 1; /* This div will grow to fill available space, pushing footer down */
        padding: 20px; /* Apply consistent horizontal and vertical padding here */
        padding-bottom: 50px; /* Space before footer */
        box-sizing: border-box;
        width: 100%; /* Ensure it takes full width to allow centering inside */
    }

    h1 {
        text-align: center;
        margin-bottom: 30px;
        font-size: 2rem;
        color: black;
    }

    fieldset {
        border: 2px solid #E6BD37;
        border-radius: 10px;
        padding: 20px;
        background: #fff; /* white background */
        width: 90%; /* Use percentage for responsiveness */
        max-width: 500px; /* Max width for larger screens */
        margin: auto; /* Center the fieldset within its parent (.main-content-wrapper) */
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        transition: transform 0.2s, box-shadow 0.2s;
        box-sizing: border-box; /* Crucial for width calculation */
    }
    fieldset:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 18px rgba(0,0,0,0.15);
    }

    legend {
        font-weight: bold;
        color: #E6BD37;
        font-size: 1.2rem; /* Consistent font size */
    }

    label {
        display: block;
        margin-top: 15px;
        font-size: 1rem;
    }

    /* Universal input styling for text, date, email, tel fields */
    input[type="text"],
    input[type="email"], /* Added for email inputs */
    input[type="tel"] {   /* Added for telephone inputs */
        width: 100%;
        padding: 10px;
        margin-top: 6px;
        font-size: 1rem;
        border-radius: 5px;
        border: 1px solid #ccc;
        background: #f9f9f9;
        box-sizing: border-box; /* Ensures padding/border are inside 100% width */
    }

    input[type="date"] {
        width: 100%;
        padding: 10px;
        margin-top: 6px;
        font-size: 1rem;
        border-radius: 5px;
        border: 1px solid #ccc;
        background: #f9f9f9;
        box-sizing: border-box;
        -webkit-appearance: none; /* Attempt to remove browser native styling for consistent appearance */
        -moz-appearance: none;
        appearance: none;
        min-width: 0; /* Allow the element to shrink as much as possible */
    }
    /* Hide the default calendar icon and spin buttons if they cause overflow or are undesirable */
    input[type="date"]::-webkit-calendar-picker-indicator,
    input[type="date"]::-webkit-inner-spin-button {
        display: none;
        -webkit-appearance: none;
    }


    input[type="submit"] {
        background: #E6BD37;
        color: #fff;
        font-weight: bold;
        margin-top: 20px;
        border: none;
        cursor: pointer;
        transition: background 0.3s, color 0.3s, border 0.3s;
        padding: 14px;
        font-size: 1.1rem;
        border-radius: 5px;
        width: 100%;
        box-sizing: border-box;
    }

    input[type="submit"]:hover {
        background: #fff;
        color: #E6BD37;
        border: 2px solid #E6BD37;
    }

    /* Responsiveness */
    @media (max-width: 768px) {
        body {
            padding-top: 130px; /* Adjust for smaller header on tablets */
        }
        .main-content-wrapper {
            padding: 15px;
            padding-bottom: 40px;
        }
        h1 {
            font-size: 1.7rem;
        }
        fieldset {
            padding: 16px;
        }
        input[type="submit"] {
            font-size: 1rem;
            padding: 10px;
        }
        label {
            font-size: 0.95rem;
        }
    }

    @media (max-width: 480px) {
        body {
            padding-top: 100px; /* Adjust for smaller header on phones */
        }
        .main-content-wrapper {
            padding: 10px; /* Reduced padding for phones to give more space */
            padding-bottom: 30px;
        }
        h1 {
            font-size: 1.5rem;
        }
        fieldset {
            padding: 12px; /* Slightly reduced padding inside fieldset */
            width: 95%; /* Make fieldset take a bit more width on very small screens */
        }
        input[type="text"],
        input[type="email"],
        input[type="tel"] {
            font-size: 0.9rem; /* Slightly smaller font for inputs */
            padding: 7px; /* Slightly less padding for inputs */
        }
        /* Explicitly set height/padding for date input on small screens */
        input[type="date"] {
            min-height: 38px; /* Ensure a good minimum height for touch */
            padding: 8px 7px; /* Adjust padding to look good with new height */
            font-size: 0.95rem; /* Larger font for date input specifically */
        }
        input[type="submit"] {
            font-size: 0.9rem;
            padding: 8px;
        }
        label {
            font-size: 0.85rem; /* Slightly smaller for labels */
        }
    }
</style>
</head>
<body>
    <div class="main-content-wrapper">
        <h1>Registration</h1>
        <form method="post" action="address_info_reg.php">
            <fieldset>
                <legend>Personal Information</legend>

                <label>First Name</label>
                <input type="text" name="first_name" required value="<?= htmlspecialchars($first_name) ?>">

                <label>Middle Name</label>
                <input type="text" name="middle_name" value="<?= htmlspecialchars($middle_name) ?>">

                <label>Last Name</label>
                <input type="text" name="last_name" required value="<?= htmlspecialchars($last_name) ?>">

                <label>Birthday</label>
                <input type="date" name="birthday" required value="<?= htmlspecialchars($birthday) ?>">

                <label>Email</label>
                <input type="email" name="email" required value="<?= htmlspecialchars($email) ?>">

                <label>Contact Number</label>
                <input type="tel" name="contact_number" required value="<?= htmlspecialchars($contact_number) ?>">

                <input type="submit" value="Next">
            </fieldset>
        </form>
    </div>

<?php include 'footer.php'; ?>
</body>
</html>