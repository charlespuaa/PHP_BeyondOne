<?php
$server = "sql210.infinityfree.com";
$user = "if0_39481257";
$password = "BeyondOne2025";
$database = "if0_39481257_etierproducts"; 

$conn = new mysqli($server, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connection_error);
}